﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1
{
    class Program
    {
        static void Main(string[] args)
        {


            try

            {


                string[] filmsname;
                int i = 0;
                int nowplaying;
                Console.WriteLine("HEY...WELCOME TO OUR MULTIPLEX");
                do
                {

                    try

                    {
                        Console.Write("ENTER THE NUMBER OF FILM MULTIPLEX IS CURRENTLY IN PLAY "); // IT TAKES THE INPUT FROM EMPLOYEES
                        nowplaying = int.Parse(Console.ReadLine());
                        if (nowplaying < 1) // CHECKS THE VALIDATION
                        {
                            Console.WriteLine("ENTER THE VALID NUMBER"); // IT SHOWS ERROR MESSAGE
                        }
                    }
                    catch (Exception e)
                    {

                        Console.WriteLine(e.Message + "ENTER VALID FILM NUMBER "); // HANDLING EXCEPTION
                        nowplaying = 0;

                    }

                }

                while (nowplaying < 1);

                filmsname = new string[nowplaying];

                do

                {
                    Console.Write(" ENTER THE FILM NAME " + (i + 1) + ":"); // TAKES INPUT FROM EMPLOYEE
                    string film = Console.ReadLine();
                    film = film.ToUpper();
                    // COMPARING WITH INPUT
                    if (film.EndsWith("(18)") ||  film.EndsWith("(15)") ||  film.EndsWith("(12A)") ||   film.EndsWith("(U)"))
                    {
                        filmsname[i] = film;

                        i++;


                    }

                    else

                    {

                        Console.WriteLine("ALL FILM ENDS WITH (18) or (12A) or (U) or (15) ONLY SO PLEASE ENTER ACCORDINGLY."); // IT CHECKS THE INPUT AND VALIDATING 
                        continue;


                    }

                }

                while (i < nowplaying);
                

                string GoToRoundAgain = "";
                do
                {
                    Console.WriteLine("HELLO....WELCOME TO MULTIPLEX");
                    Console.WriteLine("WE ARE CURRENTLY SHOWING :");


                    for (int j = 0; j < nowplaying; j++)
                    {
                        Console.WriteLine((j + 1) + "." + " " + filmsname[j]);
                    }

                    int film, age;

                    do
                    {
                        Console.Write("PLEASE ENTER THE MOVIE NUMBER FROM THE ABOVE LIST WHICH YOU WANT TO SEE" + " "); // ACCEPTS INPUT FROM CUSTOMERS
                        film = int.Parse(Console.ReadLine());


                        if ((film < 1) || (film > nowplaying))
                        {
                            Console.WriteLine("OOPS!!! INVALID NUMBER...PLEASE ENTER NUMBER AGAIN."); // WILL CHECK USERS INPUT
                        }


                    } while ((film < 1) || (film > nowplaying));

                    Boolean cages = false;


                    do
                    {

                        Console.Write("PLEASE ENTER YOUR AGE:" + " "); // TAKES AGE AS INPUT
                        age = int.Parse(Console.ReadLine());


                        if ((age < 5) || (age > 120)) // CHECKING AGE AND THEN PRINTIN MESSAGE ACCORDING TO RANGE
                        {
                            Console.WriteLine("YOUR AGE SHOULD BE BETWEEN 5 TO 120");
                            cages = false;
                        }
                        else
                        {
                            cages = true;

                        }

                    } while (cages == false);

                    if ((filmsname[film - 1].EndsWith("(15)") && age >= 15))

                    {
                        Console.WriteLine("CONGRATULATIONS...!! YOU ARE ALLOWED TO WATCH " + filmsname[film - 1] );
                    }

                    else if (filmsname[film - 1].EndsWith("(18)") && age >= 18)
                    {
                        Console.WriteLine("CONGRATULATIONS...!! YOU ARE ALLOWED TO WATCH " + filmsname[film - 1]);
                    }

                    else if (filmsname[film - 1].EndsWith("(U)") && age >= 5)
                    {
                        Console.WriteLine("CONGRATULATIONS...!! YOU ARE ALLOWED TO WATCH " + filmsname[film - 1] );
                    }

                    else if (filmsname[film - 1].EndsWith("(12A)") && age >= 5)
                    {
                        Console.WriteLine("CONGRATULATIONS...!! YOU ARE ALLOWED TO WATCH " + filmsname[film - 1] );
                    }

                    else
                    {
                        Console.WriteLine(" YOU ARE NOT ALLOWED TO WATCH THAT MOVIE BEECAUSE YOU ARE TOO YOUNG"); // When age does not match  
                    }

                    Boolean flag = false;
                    do
                    {
                        Console.Write("TYPE YES TO WATCH NEW MOVIE" + " "); // / THERE IS NEW CUSTOMER WILLING TO WATCH MOVIE THEN SAME PROCESS WILL BE REPEATED
                        GoToRoundAgain = Console.ReadLine();
                        if (GoToRoundAgain.ToUpper() == "YES" || GoToRoundAgain.ToUpper() == "Y")
                        {
                            flag = true;

                        }
                        else if(GoToRoundAgain.ToUpper() == "")
                        {
                            Environment.Exit(1);


                        }
                        else
                        {
                            Console.WriteLine("PLEASE ENTER YES ");
                            Console.WriteLine("");
                            flag = false;



                        }
                    } while (flag == false);
                } while (GoToRoundAgain.ToUpper() == "YES" || GoToRoundAgain.ToUpper() == "Y");
            }
            catch (FormatException)
            {
                Console.WriteLine("PLEASE INPUT VALID MOVIE AND / OR AGE");    // DISPLAY OF ERROE MESSAGE IF WRONG INPUT.
            }
            Console.Read();
        }
    }
}
